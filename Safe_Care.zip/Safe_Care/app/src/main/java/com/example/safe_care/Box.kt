package com.example.safe_care

import android.graphics.RectF

class Box(val rectF: RectF, val label: String, val isMask: Boolean)